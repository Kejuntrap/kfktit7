import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_190402d extends PApplet {

float[] center={6.0f, 0.0f, 0.0f};  //立体の中心座標
float[][] vertex=new float[3645][3];
int[][] polygon=new int[6320][3];
float[][] calc_V=new float[3645][3];    //計算用の変数　誤差が積もって爆発したので対策を講じた

float[] vec_unit_rotate={1/(float)Math.sqrt(3), 1/(float)Math.sqrt(3), 1/(float)Math.sqrt(3)};  //回転軸の単位ベクトル
float rotate_angle=0;  //回転速度 \theta/s
long counter=0;
float[][] v_draw=new float[3645][2];  //3次元から2次元に落とし込む
float kyoudo=0;
long time=0;


public void setup() {
  
  frameRate(60);
  background(0);
  textSize(32);
  String l;
  String[] lines;
  lines=loadStrings("vertex.pd");
  for (int i=0; i<lines.length; i++) {
    l=lines[i];
    String[] co=split(l, ',');
    vertex[i][0]=Float.parseFloat(co[0]);
    vertex[i][1]=Float.parseFloat(co[1]);
    vertex[i][2]=Float.parseFloat(co[2]);
  }

  lines=loadStrings("polygon.pd");
  for (int i=0; i<lines.length; i++) {
    l=lines[i];
    String[] co=split(l, ',');
    polygon[i][0]=Integer.parseInt(co[0]);
    polygon[i][1]=Integer.parseInt(co[1]);
    polygon[i][2]=Integer.parseInt(co[2]);
  }
  println("done");
}

public void draw() {
  background(0);
  time=millis();
  calc(rotate_angle, vec_unit_rotate);
  convert3Dto2D();
  stroke(255);
  /*for(int i=0; i<6320; i++){
   for(int j=0; j<3; j++){
   line((float)v_draw[polygon[i][j]][0],(float)v_draw[polygon[i][j]][1],(float)v_draw[polygon[i][(j+1)%3]][0],(float)v_draw[polygon[i][(j+1)%3]][1]);
   }
   }*/
  fill(255);
  int num=0;
  for (int i=0; i<6320; i++) {
    if (culling(polygon[i])) {
      fill((int)(255*kyoudo));
      stroke((int)(255*kyoudo));
      triangle((float)v_draw[polygon[i][0]][0], (float)v_draw[polygon[i][0]][1], (float)v_draw[polygon[i][1]][0], (float)v_draw[polygon[i][1]][1], (float)v_draw[polygon[i][2]][0], (float)v_draw[polygon[i][2]][1]);
      num++;
    }
  }
  counter+=2;
  counter%=720;
  rotate_angle=((float)counter);
  long now=millis();
  fill(255);
  text("Rendered \t"+(num)+" polygon(s)", 10, 10, 600, 40);
  text("Rendered \t"+(now-time)+" ms", 10, 60, 600, 40);
  time=now;
}

public void convert3Dto2D() {
  for (int i=0; i<3645; i++) {
    float tmpx=center[0]+calc_V[i][0];
    float tmpy=center[1]+calc_V[i][1];
    float tmpz=center[2]+calc_V[i][2];
    v_draw[i][0]=400+400*(tmpy/Math.abs(tmpx));  //y
    v_draw[i][1]=400+400*(tmpz/Math.abs(tmpx));   //z　画面でいうと
  }
}

public void calc(float ang, float[] vec) {
  float c=(float)Math.cos(ang*Math.PI/180);
  float s=(float)Math.sin(ang*Math.PI/180);
  float[][] rotate_matrix={
    {c+vec[0]*vec[0]*(1-c), vec[0]*vec[1]*(1-c)-vec[2]*s, vec[0]*vec[2]*(1-c)+vec[1]*s}, 
    {vec[1]*vec[0]*(1-c)+vec[2]*s, c+vec[1]*vec[1]*(1-c), vec[1]*vec[2]*(1-c)-vec[0]*s}, 
    {vec[2]*vec[0]*(1-c)-vec[1]*s, vec[2]*vec[1]*(1-c)+vec[0]*s, c+vec[2]*vec[2]*(1-c)}
  };

  for (int i=0; i<3645; i++) {
    for (int j=0; j<3; j++) {
      float v=vertex[i][j];
      float ans=0;
      for (int k=0; k<3; k++) {
        ans+=rotate_matrix[j][k]*vertex[i][k];
      }
      calc_V[i][j]=ans;
    }
  }
}

public boolean culling(int[] poly) {    //カリング（描写量を減らす）
  float[] cen={0, 0, 0};  //カメラ
  float[] vert={0, 0, 0};
  float c_d=0;
  float v_d=0;
  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      cen[i]+=calc_V[poly[j]][i];
    }
    cen[i]/=3.0f;
  }
  for (int i=0; i<3; i++) {
    cen[i]+=center[i];
  }
  c_d=(float)Math.sqrt(cen[0]*cen[0]+cen[1]*cen[1]+cen[2]*cen[2]);
  for (int i=0; i<3; i++) {
    cen[i]/=c_d;
  }

  float[] v1={calc_V[poly[1]][0]-calc_V[poly[0]][0], calc_V[poly[1]][1]-calc_V[poly[0]][1], calc_V[poly[1]][2]-calc_V[poly[0]][2]};
  float[] v2={calc_V[poly[2]][0]-calc_V[poly[0]][0], calc_V[poly[2]][1]-calc_V[poly[0]][1], calc_V[poly[2]][2]-calc_V[poly[0]][2]};

  vert[0]=v1[1]*v2[2]-v1[2]*v2[1];
  vert[1]=v1[2]*v2[0]-v1[0]*v2[2];
  vert[2]=v1[0]*v2[1]-v1[1]*v2[0];  //法線ベクトル

  v_d=(float)Math.sqrt(vert[0]*vert[0]+vert[1]*vert[1]+vert[2]*vert[2]);
  for (int i=0; i<3; i++) {
    vert[i]/=v_d;
  }
  float cul=cen[0]*vert[0]+cen[1]*vert[1]+cen[2]*vert[2];
  kyoudo=Math.abs(cul);
  if (kyoudo>1) {
    kyoudo=1;
  }
  if (cul<0.02f) {

    return true;
  } else {
    return false;
  }
}
  public void settings() {  size(800, 800, P2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_190402d" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
