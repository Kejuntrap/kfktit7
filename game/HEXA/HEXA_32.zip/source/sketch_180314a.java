import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_180314a extends PApplet {

float kakudo = 0.0f;  // kaiten suru bou no kakudo
long frames=1;      // frames jikan wo hakaru
int rotatewise=1;    // kaiten houkou wo kimeru
int kaku=6;          // sikaku or gokakkei or rokkakei
float omega=0.8f;    //mawaru hayasa
float first_spd=0.8f;//saisyo no hayasa
int ookisa=40;      // cyuuou no zukei no ookisa
int volume_of_obstacles=0;
int yoketakazu=0;    // obstacle wo yoketa kazu
int bonus=0;        // obstacle wo yoketa bonus
int time_score=0;    //jikan score
int x_pos=0;      //x zahyo
int y_pos=0;      //y zahyo
boolean game_flag=true;    // game ga ugoiteiruka
int muteki=0;      // muteki jikan
int iro=0;

PFont myFont;            //font
PFont game_ov; 

Obstacle[] obs=new Obstacle[10];

public void setup(){
  
  frameRate(120);
  myFont = loadFont("NASDAQER-12.vlw");            //font
  //myFont = loadFont("CenturyGothic-Bold-12.vlw");   
  game_ov=loadFont("CenturyGothic-Bold-48.vlw"); 
  textFont(myFont);
}

public void initialize(){      //syoki ka syori
  kakudo = 0.0f;  // kaiten suru bou no kakudo
  frames=1;      // frames jikan wo hakaru
  rotatewise=1;    // kaiten houkou wo kimeru
  kaku=6;          // sikaku or gokakkei or rokkakei
  omega=0.8f;    //mawaru hayasa
  first_spd=0.8f;//saisyo no hayasa
  ookisa=40;      // cyuuou no zukei no ookisa
  volume_of_obstacles=0;
  yoketakazu=0;    // obstacle wo yoketa kazu
  bonus=0;        // obstacle wo yoketa bonus
  time_score=0;    //jikan score
  x_pos=0;      //x zahyo
  y_pos=0;      //y zahyo
  game_flag=true;    // game ga ugoiteiruka
  obs=new Obstacle[10];
  muteki=0;
  iro=0;
}

public void draw(){
  if(game_flag==true){
    background(0);
    stroke(255);
    colorMode( HSB, 360, 100, 100 );
    fill(iro,100,100);
    rtt();
    kakusu();
    
    if(frames%120==0 && volume_of_obstacles<10){
      obs[volume_of_obstacles]=new Obstacle();
      obs[volume_of_obstacles].create();
      volume_of_obstacles++;
      yoketakazu++;
    }
    if(frames%720==0){
      iro=(int) (Math.random()*360);
    }
    
    for(int i=0; i<volume_of_obstacles; i++){
      obs[i].upd();
    }
    
    cyu_sin(kaku);
    grid_line(kaku);
    mouse_draw();
    text_show();
    frames++;
    time_score=(int) frames/9;
    
    if(muteki>0){
      muteki--;
    }
  }
  
  else if(game_flag==false){
    textFont(game_ov);
    fill(255);
    text("GAME OVER",170,320);
    textFont(myFont);
  }
}

public void keyPressed(){
  if (key == 'r') {
    initialize();
  }
}

public void grid_line(int k){      //senn wo hiku rotine
  for(int i=0; i<k; i++){
    line(320,320,320+600*cos((kakudo+(360*i)/k)*3.1415f*2/360),320+600*sin((kakudo+(360*i)/k)*3.1415f*2/360));
  }
}

public void rtt(){          // senn wo mawasu routine  mawasu houkou mo seigyo simasu
  if(frames%300==0){
    double rand=Math.random();
    if(rand>0.5f){
      rotatewise=rotatewise*(-1);
    }
  }
  kakudo=(kakudo+omega*rotatewise)%360;
  if(omega<2.4f){
    omega+=0.0001333f;
  }
}

public void kakusu(){          // senn no kazu wo kimemasu 
  if(frames%600==0){
    double rand=Math.random();
    if(rand<0.33f){
      if(kaku==4){kaku=5; muteki=90;}
      else if(kaku==5){kaku=6; muteki=90;}
      else if(kaku==6){kaku=6;}
    }
    
    else if(rand>=0.33f && 0.67f>rand && kaku>4 && kaku<=6){
      if(kaku==4){kaku=4;}
      else if(kaku==5){kaku=5;}
      else if(kaku==6){kaku=5; muteki=90;}
    }
    
    else if(rand>=0.67f){
      if(kaku==4){kaku=4;}
      else if(kaku==5){kaku=4; muteki=90;}
      else if(kaku==6){kaku=6;}
    }
  }
}

public void text_show(){          // jyouhou wo simesu text wo hyouji simasu
 text("TIME: "+nf((float)frames/120,2,3), 2, 2, 240, 40);
 text("SPEED x"+nf((float)omega/first_spd,1,3), 2, 14, 180, 40);
 text("SCORE: "+(bonus+time_score), 2, 28, 180, 40); 
}

public void cyu_sin(int k){//cyuusin no zeukei wo kakumasu
  for(int i=0; i<k; i++){
    stroke(255);
    line(320+ookisa*cos(radians(kakudo+(360*i)/k)),320+ookisa*sin(radians(kakudo+(360*i)/k)),320+ookisa*cos(radians(kakudo+(360*(i+1))/k)),320+ookisa*sin(radians(kakudo+(360*(i+1))/k)));
    // ookisa * kakudo+ takakkei no cyoutenn kara tonari no cyouten wo musubu
  }
  
}


public void mouse_draw(){
  int px=mouseX;
  int py=mouseY;
  px=px-320;
  py=py-320;
  float kibo=(float) Math.sqrt(px*px+py*py);
  ellipse(320+px*60/kibo, 320+py*60/kibo, 8,8);
}



class Obstacle{
  int interval;
  int type;    //syougaibutu no katachi
  int dist;    // cyusin kara no kyori  0 ni naruto zukei syoumetu
  int muki;    // obstacle no muki
  boolean use=true;    // object ga yuukou ka mukou ka
  float b_wid=(float) (20+30*Math.random());    // obstacle no  futosa
  float ball_kakudo;    // ball no aru kakudo
  boolean collision_ball=false;    // obstacle to ball no syoutotu
  public void create(){
    type=((int) (Math.random()*256))%3;
    muki=(int) (Math.random()*60);    // 4 5 6 LCM
    use=true;
    dist=500;
    interval=1;
    ball_kakudo=0;
  }
  
  public void upd(){
    noStroke();
    if(dist>=0 && use==true){    // object yuukou no toki
      dist-=2;
      if(type == 0){    // pattern 1   obstacle 1tu
        quad(320+dist*cos(radians(kakudo+(360*muki)/kaku)),320+dist*sin(radians(kakudo+(360*muki)/kaku)),320+dist*cos(radians(kakudo+(360*(muki+1))/kaku)),320+dist*sin(radians(kakudo+(360*(muki+1))/kaku)),320+(dist+b_wid)*cos(radians(kakudo+(360*(muki+1))/kaku)),320+(dist+b_wid)*sin(radians(kakudo+(360*(muki+1))/kaku)),320+(dist+b_wid)*cos(radians(kakudo+(360*muki)/kaku)),320+(dist+b_wid)*sin(radians(kakudo+(360*muki)/kaku)));
        collision_ball=atari_1();
        
        if(collision_ball==true){ game_flag=false;}
        else if(collision_ball==false){}
        
      }
      
      else if(type==1){
        for(int i=0; i<(kaku+1)/2; i++){
          quad(320+dist*cos(radians(kakudo+(360*(muki+2*i))/kaku)),320+dist*sin(radians(kakudo+(360*(muki+2*i))/kaku)),320+dist*cos(radians(kakudo+(360*((muki+2*i)+1))/kaku)),320+dist*sin(radians(kakudo+(360*((muki+2*i)+1))/kaku)),320+(dist+b_wid)*cos(radians(kakudo+(360*((muki+2*i)+1))/kaku)),320+(dist+b_wid)*sin(radians(kakudo+(360*((muki+2*i)+1))/kaku)),320+(dist+b_wid)*cos(radians(kakudo+(360*(muki+2*i))/kaku)),320+(dist+b_wid)*sin(radians(kakudo+(360*(muki+2*i))/kaku)));
          collision_ball=atari_2();
          if(collision_ball==true){ game_flag=false;}
          else if(collision_ball==false){}
        }
      }
      
      else if(type==2){
        for(int i=0; i<kaku-1; i++){
          quad(320+dist*cos(radians(kakudo+(360*(muki+i))/kaku)),320+dist*sin(radians(kakudo+(360*(muki+i))/kaku)),320+dist*cos(radians(kakudo+(360*(muki+i+1)/kaku))),320+dist*sin(radians(kakudo+(360*(muki+i+1)/kaku))),320+(dist+b_wid)*cos(radians(kakudo+360*(muki+i+1)/kaku)),320+(dist+b_wid)*sin(radians(kakudo+360*(muki+i+1)/kaku)),320+(dist+b_wid)*cos(radians(kakudo+360*(muki+i)/kaku)),320+(dist+b_wid)*sin(radians(kakudo+360*(muki+i)/kaku)));
          collision_ball=atari_3();
          if(collision_ball==true){ game_flag=false;}
          else if(collision_ball==false){}
        }
      } 
    }
    
    else if(dist<ookisa && use==true){    // object wo mukouka
      use=false;
      bonus+=(type+1)*10;
      
    }
    else if(use==false){      // mukou no toki nanimo sinai
      interval++;
      if(interval% 1000 == 0){
        yoketakazu++;
        create();
      }
    }
  }
  
  public boolean atari_1() {   // pattern 1 no atari hantei
  
    ball_kakudo =(degrees(atan2(mouseY-320, mouseX-320)*-1)+360)%360;      
    if(ball_kakudo-180/kaku <= 0 && muteki==0){                                                            // ball  no aru kakudo ga chiisaitoki  (365do to 5do ga konzai surutoki)
      if(360-(kakudo+(360*muki+360)/kaku)%360 < 360-(kakudo+(360*muki)/kaku)%360){
        if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
      
      else if(360-(kakudo+(360*muki+360)/kaku)%360 > 360-(kakudo+(360*muki)/kaku)%360 && muteki==0){
        if( ball_kakudo+360 >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
    }
    
    else if(ball_kakudo+180/kaku >= 360 && muteki==0){                                                // ball  no aru kakudo ga ookiitoki  (365do to 5do ga konzai surutoki)
      if(360-(kakudo+(360*muki+360)/kaku)%360 < 360-(kakudo+(360*muki)/kaku)%360){
        if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
      
      else if(360-(kakudo+(360*muki+360)/kaku)%360 > 360-(kakudo+(360*muki)/kaku)%360 && muteki==0){
        if( ball_kakudo+360 >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
    }
    
    else{                                      // soreigai
      if(360-(kakudo+(360*muki+360)/kaku)%360 < 360-(kakudo+(360*muki)/kaku)%360 && muteki==0){
        if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
      
      else if(360-(kakudo+(360*muki+360)/kaku)%360 > 360-(kakudo+(360*muki)/kaku)%360 && muteki==0){
        if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 720-(kakudo+(360*muki)/kaku)%360){
          if(dist<64 && dist>56-b_wid){
            return true;
          }
        }
      }
    }
    return false;
  }
  
  public boolean atari_2() {      //pattern 2 no atari hantei
    ball_kakudo =(degrees(atan2(mouseY-320, mouseX-320)*-1)+360)%360;
                    
    for(int i=0; i<(kaku+1)/2; i++){
      if(ball_kakudo-180/kaku <= 0 && muteki==0){      // ball  no aru kakudo ga chiisaitoki  (365do to 5do ga konzai surutoki)
        if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 < 360-(kakudo+(360*(muki+i*2))/kaku)%360){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 > 360-(kakudo+(360*(muki+i*2))/kaku)%360 && muteki==0){
          if( ball_kakudo+360 >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
      
      else if(ball_kakudo+180/kaku >= 360 && muteki==0){    // ball  no aru kakudo ga ookiitoki  (365do to 5do ga konzai surutoki)
        if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 < 360-(kakudo+(360*(muki+i*2))/kaku)%360){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 > 360-(kakudo+(360*(muki+i*2))/kaku)%360 && muteki==0){
          if( ball_kakudo+360 >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
      
      else{      //soreigai
        if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 < 360-(kakudo+(360*(muki+i*2))/kaku)%360 && muteki==0){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i*2+1))/kaku)%360 > 360-(kakudo+(360*(muki+i*2))/kaku)%360 && muteki==0){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i*2+1))/kaku)%360 && ball_kakudo <= 720-(kakudo+(360*(muki+i*2))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
    }
    return false;
  }
  
    public boolean atari_3() {      //pattern 2 no atari hantei
    ball_kakudo =(degrees(atan2(mouseY-320, mouseX-320)*-1)+360)%360;
                    
    for(int i=0; i<kaku-1; i++){
      if(ball_kakudo-180/kaku <= 0 && muteki==0){    // ball  no aru kakudo ga chiisaitoki  (365do to 5do ga konzai surutoki)
        if(360-(kakudo+(360*(muki+i+1))/kaku)%360 < 360-(kakudo+(360*(muki+i))/kaku)%360){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i+1))/kaku)%360 > 360-(kakudo+(360*(muki+i))/kaku)%360 && muteki==0){
          if( ball_kakudo+360 >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
      
      else if(ball_kakudo+180/kaku >= 360 && muteki==0){    // ball  no aru kakudo ga ookiitoki  (365do to 5do ga konzai surutoki)
        if(360-(kakudo+(360*(muki+i+1))/kaku)%360 < 360-(kakudo+(360*(muki+i))/kaku)%360){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i+1))/kaku)%360 > 360-(kakudo+(360*(muki+i))/kaku)%360 && muteki==0){
          if( ball_kakudo+360 >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo+360 <= 720-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
      
      else{      //soreigai
        if(360-(kakudo+(360*(muki+i+1))/kaku)%360 < 360-(kakudo+(360*(muki+i))/kaku)%360 && muteki==0){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
        
        else if(360-(kakudo+(360*(muki+i+1))/kaku)%360 > 360-(kakudo+(360*(muki+i))/kaku)%360 && muteki==0){
          if( ball_kakudo >= 360-(kakudo+(360*(muki+i+1))/kaku)%360 && ball_kakudo <= 720-(kakudo+(360*(muki+i))/kaku)%360){
            if(dist<64 && dist>56-b_wid){
              return true;
            }
          }
        }
      }
    }

    return false;
  }
}









    
    
    /*
    if(360-(kakudo+(360*muki+360)/kaku)%360 < 360-(kakudo+(360*muki)/kaku)%360){
      if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 360-(kakudo+(360*muki)/kaku)%360){
        if(dist<64 && dist>56-b_wid){
          return true;
        }
      }
    }
    
    else if(360-(kakudo+(360*muki+360)/kaku)%360 > 360-(kakudo+(360*muki)/kaku)%360){
      if( ball_kakudo >= 360-(kakudo+(360*muki+360)/kaku)%360 && ball_kakudo <= 720-(kakudo+(360*muki)/kaku)%360){
        if(dist<64 && dist>56-b_wid){
          return true;
        }
      }
    }*/
  public void settings() {  size(640,640); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_180314a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
